import json
from database import get_connection

c = get_connection()
cur = c.cursor(dictionary=True)
cur.execute('SELECT * FROM locations')
locations = cur.fetchall()

cur.execute('SELECT accident_id, DATE_FORMAT(accident_datetime, "%Y-%m-%d %H:%i:%s") as accident_datetime, location_id, vehicle_type, severity, weather FROM accidents')
accidents = cur.fetchall()
cur.close()
c.close()

with open('backup/db_backup.json', 'w') as f:
    json.dump({'locations': locations, 'accidents': accidents}, f, indent=2)

print(f"Database backup saved to backup/db_backup.json with {len(locations)} locations and {len(accidents)} accidents.")

