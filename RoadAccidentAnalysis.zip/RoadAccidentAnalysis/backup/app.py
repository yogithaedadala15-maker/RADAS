from flask import Flask, render_template, request, redirect, url_for, flash
from database import get_connection
from analysis import analyze_accidents, get_accident_summary

from datetime import datetime

app = Flask(__name__)
app.secret_key = "road_accident_project_key"


# =====================================================
# DASHBOARD
# =====================================================
@app.route("/")
def home():
    summary = get_accident_summary()

    return render_template(
        "index.html",
        total_accidents=summary["total_accidents"],
        most_affected_region=summary["most_affected_region"],
        most_common_vehicle=summary["most_common_vehicle"],
        busiest_hour=summary["busiest_hour"],
        severity_counts=summary["severity_counts"],
        severity_percentages=summary["severity_percentages"]
    )


# =====================================================
# ACCIDENT RECORDS
# =====================================================
@app.route("/accidents")
def view_accidents():
    print("ACCIDENT RECORDS ROUTE OPENED")
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                a.accident_id,
                a.accident_datetime,
                l.region,
                l.road_name,
                a.vehicle_type,
                a.severity,
                a.weather
            FROM accidents a
            JOIN locations l
                ON a.location_id = l.location_id
            ORDER BY a.accident_datetime DESC
        """)

        accidents = cursor.fetchall()

        return render_template(
            "accidents.html",
            accidents=accidents
        )

    except Exception as error:
        app.logger.exception("Unable to load accident records")
        return f"Unable to load accident records. Check the VS Code terminal for details. Error: {error}", 500

    finally:
        if cursor:
            cursor.close()

        if connection and connection.is_connected():
            connection.close()


# =====================================================
# ANALYSIS PAGE
# =====================================================
@app.route("/analysis")
def show_analysis():
    analyze_accidents()
    summary = get_accident_summary()

    return render_template(
        "analysis.html",
        chart_files=[
            "hourly_accidents.png",
            "location_accidents.png",
            "severity_accidents.png",
            "time_period_accidents.png"
        ],
        total_accidents=summary["total_accidents"],
        most_affected_region=summary["most_affected_region"],
        most_common_vehicle=summary["most_common_vehicle"],
        busiest_hour=summary["busiest_hour"],
        severity_counts=summary["severity_counts"],
        severity_percentages=summary["severity_percentages"]
    )


# =====================================================
# ADD ACCIDENT
# =====================================================
@app.route("/add-accident", methods=["POST"])
def add_accident():
    accident_datetime = request.form.get("accident_datetime", "").strip()
    region = request.form.get("region", "").strip()
    road_name = request.form.get("road_name", "").strip()
    vehicle_type = request.form.get("vehicle_type", "").strip()
    severity = request.form.get("severity", "").strip()
    weather = request.form.get("weather", "").strip()

    allowed_vehicles = {"Car", "Bike", "Bus", "Truck", "Auto", "Other"}
    allowed_severities = {"Minor", "Serious", "Fatal"}
    allowed_weather = {"Clear", "Rainy", "Foggy", "Other"}

    if not accident_datetime or not region or not vehicle_type or not severity:
        flash("Please fill in all required fields.", "error")
        return redirect(url_for("home") + "#add-accident")

    try:
        parsed_datetime = datetime.fromisoformat(accident_datetime)
    except ValueError:
        flash("Please enter a valid accident date and time.", "error")
        return redirect(url_for("home") + "#add-accident")

    if parsed_datetime > datetime.now():
        flash("Accident date and time cannot be in the future.", "error")
        return redirect(url_for("home") + "#add-accident")

    if len(region) > 100 or len(road_name) > 150:
        flash("Region or road name is too long.", "error")
        return redirect(url_for("home") + "#add-accident")

    if vehicle_type not in allowed_vehicles:
        flash("Please select a valid vehicle type.", "error")
        return redirect(url_for("home") + "#add-accident")

    if severity not in allowed_severities:
        flash("Please select a valid severity.", "error")
        return redirect(url_for("home") + "#add-accident")

    if weather and weather not in allowed_weather:
        flash("Please select valid weather.", "error")
        return redirect(url_for("home") + "#add-accident")

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(
            "SELECT location_id FROM locations WHERE region = %s AND road_name <=> %s LIMIT 1",
            (region, road_name or None)
        )

        location = cursor.fetchone()

        if location:
            location_id = location["location_id"]
        else:
            cursor.execute(
                "INSERT INTO locations (region, road_name) VALUES (%s, %s)",
                (region, road_name or None)
            )
            location_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO accidents
                (accident_datetime, location_id, vehicle_type, severity, weather)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            parsed_datetime,
            location_id,
            vehicle_type,
            severity,
            weather or None
        ))

        connection.commit()
        flash("Accident record added successfully!", "success")

    except Exception:
        if connection:
            connection.rollback()

        app.logger.exception("Unable to add accident record")
        flash("Unable to add the record. Check the VS Code terminal.", "error")

    finally:
        if cursor:
            cursor.close()

        if connection and connection.is_connected():
            connection.close()

    return redirect(url_for("home") + "#add-accident")


# =====================================================
# RUN APPLICATION
# =====================================================
if __name__ == "__main__":
    app.run(debug=True)
