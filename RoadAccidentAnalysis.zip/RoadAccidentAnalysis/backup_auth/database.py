import os
import mysql.connector

def get_connection():
    connection = mysql.connector.connect(
        host=os.environ.get("DB_HOST", "localhost"),
        user=os.environ.get("DB_USER", "root"),
        password=os.environ.get("DB_PASSWORD", "Bhavi@6783"),
        database=os.environ.get("DB_NAME", "road_accident_db")
    )
    return connection
