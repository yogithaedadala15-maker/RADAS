import os
from werkzeug.security import generate_password_hash
from database import get_connection

def init_database():
    connection = get_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        # 1. Create users table if not exists (preserves accidents & locations tables)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        connection.commit()
        print("Table 'users' verified / created successfully.")

        # 2. Check if admin user exists; create default if table is empty
        cursor.execute("SELECT COUNT(*) as count FROM users")
        user_count = cursor.fetchone()["count"]

        if user_count == 0:
            default_user = os.environ.get("ADMIN_USERNAME", "admin")
            default_pass = os.environ.get("ADMIN_PASSWORD", "Admin@123")
            pw_hash = generate_password_hash(default_pass)

            cursor.execute(
                "INSERT INTO users (username, password_hash) VALUES (%s, %s)",
                (default_user, pw_hash)
            )
            connection.commit()
            print(f"Default admin user created: username='{default_user}'")
        else:
            print(f"Users table already contains {user_count} account(s).")

    finally:
        cursor.close()
        connection.close()

if __name__ == "__main__":
    init_database()

